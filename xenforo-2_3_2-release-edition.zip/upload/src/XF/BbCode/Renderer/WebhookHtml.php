<?php

namespace XF\BbCode\Renderer;

class WebhookHtml extends ApiHtml
{
}
