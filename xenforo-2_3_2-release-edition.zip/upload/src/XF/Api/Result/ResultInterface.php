<?php

namespace XF\Api\Result;

/**
 * @deprecated
 */
interface ResultInterface extends \XF\Entity\ResultInterface
{
}
